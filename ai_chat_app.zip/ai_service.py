"""
AI 服务 - 改造为融合傻酒馆角色卡 + 世界书 + 经历的 Prompt 生成
"""
import os
import re
import random
import httpx
from typing import Optional, List, Tuple
from datetime import datetime
from sqlalchemy.orm import Session
from database import Character, Experience, User, WorldBook, LoreEntry, CharacterWorldBook

# AI API 配置 - 从环境变量读取
AI_API_KEY = os.getenv("OPENAI_API_KEY", "")
AI_API_BASE = os.getenv("OPENAI_API_BASE", "https://dashscope.aliyuncs.com/compatible-mode/v1")
AI_MODEL = os.getenv("AI_MODEL", "qwen-plus")


def _get_bound_worldbooks(character_id: int, db: Session) -> List[WorldBook]:
    """获取角色绑定的世界书"""
    bindings = db.query(CharacterWorldBook).filter(
        CharacterWorldBook.character_id == character_id
    ).all()
    
    worldbook_ids = [b.worldbook_id for b in bindings]
    if not worldbook_ids:
        return []
    
    return db.query(WorldBook).filter(WorldBook.id.in_(worldbook_ids)).all()


def _scan_lore_entries(
    worldbooks: List[WorldBook],
    chat_history: List[str],
    db: Session
) -> Tuple[List[str], List[str]]:
    """
    扫描聊天历史，激活匹配的世界书条目
    返回 (before_char_entries, after_char_entries)
    """
    # 合并所有世界书的条目
    all_entries = []
    for wb in worldbooks:
        for entry in wb.entries:
            if not entry.enabled:
                continue
            all_entries.append((wb, entry))
    
    if not all_entries:
        return [], []
    
    # 构建扫描文本（最近的聊天消息）
    scan_text = '\n'.join(chat_history[-50:])  # 默认扫描最近50条
    
    activated = []
    
    for wb, entry in all_entries:
        # 常驻条目始终激活
        if entry.constant:
            activated.append(entry)
            continue
        
        # 确定扫描深度
        depth = entry.scan_depth if entry.scan_depth > 0 else wb.scan_depth
        scan_messages = chat_history[-depth:] if depth > 0 else chat_history
        entry_scan_text = '\n'.join(scan_messages)
        
        # 检查主关键词匹配
        keys = [k.strip() for k in entry.keys.split(',') if k.strip()]
        if not keys:
            continue
        
        primary_match = _check_keys_match(
            keys, entry_scan_text, 
            entry.case_sensitive, entry.use_regex
        )
        
        if not primary_match:
            continue
        
        # 选择性模式：需要同时匹配次要关键词
        if entry.selective:
            secondary_keys = [k.strip() for k in entry.secondary_keys.split(',') if k.strip()]
            if secondary_keys:
                secondary_match = _check_keys_match(
                    secondary_keys, entry_scan_text,
                    entry.case_sensitive, entry.use_regex
                )
                if not secondary_match:
                    continue
        
        # 概率检查
        if entry.probability < 100:
            if random.randint(1, 100) > entry.probability:
                continue
        
        activated.append(entry)
    
    # 按优先级排序（高优先级在前），同优先级按 insertion_order 排序
    activated.sort(key=lambda e: (-e.priority, e.insertion_order))
    
    # 按 position 分组
    before_char = []
    after_char = []
    for entry in activated:
        if entry.position == 'after_char':
            after_char.append(entry.content)
        else:
            before_char.append(entry.content)
    
    return before_char, after_char


def _check_keys_match(keys: List[str], text: str, case_sensitive: bool, use_regex: bool) -> bool:
    """检查关键词是否在文本中匹配"""
    for key in keys:
        if not key:
            continue
        
        if use_regex:
            try:
                flags = 0 if case_sensitive else re.IGNORECASE
                if re.search(key, text, flags):
                    return True
            except re.error:
                # 正则表达式错误，回退到普通匹配
                if case_sensitive:
                    if key in text:
                        return True
                else:
                    if key.lower() in text.lower():
                        return True
        else:
            if case_sensitive:
                if key in text:
                    return True
            else:
                if key.lower() in text.lower():
                    return True
    
    return False


def _get_recent_experiences(character_id: int, db: Session, limit: int = 7) -> List[Experience]:
    """获取角色最近的经历"""
    return db.query(Experience).filter(
        Experience.character_id == character_id
    ).order_by(Experience.date.desc()).limit(limit).all()


def generate_character_prompt(
    character: Character,
    user: User,
    db: Session,
    chat_history: Optional[List[str]] = None
) -> str:
    """
    生成完整的系统提示词
    融合: 角色卡 system_prompt + 世界书 + 角色描述 + 经历 + 亲密度
    """
    if chat_history is None:
        chat_history = []
    
    parts = []
    
    # 1. 世界书 before_char 条目
    worldbooks = _get_bound_worldbooks(character.id, db)
    before_char_entries, after_char_entries = _scan_lore_entries(worldbooks, chat_history, db)
    
    if before_char_entries:
        parts.append("【世界知识】\n" + '\n'.join(before_char_entries))
    
    # 2. 角色卡 system_prompt（如果有的话，作为最高优先级的系统指令）
    if character.system_prompt:
        # 替换傻酒馆占位符
        sys_prompt = character.system_prompt
        sys_prompt = sys_prompt.replace('{{char}}', character.name)
        sys_prompt = sys_prompt.replace('{{user}}', user.username)
        parts.append(sys_prompt)
    
    # 3. 角色描述和设定
    char_desc_parts = []
    
    if character.description:
        char_desc_parts.append(f"【角色描述】\n{character.description}")
    
    if character.personality:
        char_desc_parts.append(f"【性格特征】\n{character.personality}")
    
    # 兼容旧字段
    if character.background and not character.description:
        char_desc_parts.append(f"【生平背景】\n{character.background}")
    if character.habits and not character.personality:
        char_desc_parts.append(f"【回复习惯】\n{character.habits}")
    if character.world_view and not character.scenario:
        char_desc_parts.append(f"【世界观】\n{character.world_view}")
    
    if character.scenario:
        char_desc_parts.append(f"【场景设定】\n{character.scenario}")
    
    if char_desc_parts:
        parts.append('\n'.join(char_desc_parts))
    
    # 4. 世界书 after_char 条目
    if after_char_entries:
        parts.append("【补充设定】\n" + '\n'.join(after_char_entries))
    
    # 5. 对话示例
    if character.mes_example:
        # 清理 <START> 标记
        examples = character.mes_example.replace('<START>', '').strip()
        if examples:
            parts.append(f"【对话示例】\n{examples}")
    
    # 6. 最近经历
    recent_experiences = _get_recent_experiences(character.id, db)
    if recent_experiences:
        exp_text = "【最近的经历】\n"
        for exp in reversed(recent_experiences):
            date_str = exp.date.strftime("%Y-%m-%d")
            exp_text += f"- {date_str}: {exp.content}\n"
        parts.append(exp_text)
    
    # 7. 亲密度和互动指引
    parts.append(f"""【当前状态】
- 与用户({user.username})亲密度: {user.intimacy:.1f}/100
- 亲密度越高，关系越亲密，语气越自然亲近

【重要提示】
1. 始终保持角色人设，不要跳出角色
2. 根据亲密度调整语气和距离感
3. 回复要符合角色的性格和说话习惯
4. 可以适当提及最近的经历，让对话更真实
5. 回复控制在100-300字左右，自然流畅""")
    
    # 8. post_history_instructions（如果有）
    if character.post_history_instructions:
        phi = character.post_history_instructions
        phi = phi.replace('{{char}}', character.name)
        phi = phi.replace('{{user}}', user.username)
        parts.append(phi)
    
    return '\n\n'.join(parts)


async def chat_with_ai(
    message: str,
    character: Character,
    user: User,
    db: Session,
    conversation_history: Optional[List[dict]] = None
) -> str:
    """与AI角色对话"""
    
    # 构建聊天历史文本（用于世界书扫描）
    chat_text_history = []
    if conversation_history:
        for msg in conversation_history:
            chat_text_history.append(msg.get('content', ''))
    chat_text_history.append(message)
    
    system_prompt = generate_character_prompt(
        character, user, db, chat_text_history
    )
    
    messages = [{"role": "system", "content": system_prompt}]
    
    if conversation_history:
        messages.extend(conversation_history)
    
    messages.append({"role": "user", "content": message})
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{AI_API_BASE}/chat/completions",
                headers={
                    "Authorization": f"Bearer {AI_API_KEY}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": AI_MODEL,
                    "messages": messages,
                    "temperature": 0.8,
                    "max_tokens": 500
                },
                timeout=30.0
            )
            
            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"]
            else:
                return f"[{character.name}] 嗯...让我想想...（AI服务暂时不可用，请检查API配置）"
    
    except Exception as e:
        return f"[{character.name}] 啊，刚才有点走神了...（连接错误: {str(e)[:50]}）"


def update_intimacy(user: User, message_content: str, db: Session):
    """根据聊天内容更新亲密度"""
    increase = 0.5
    
    if len(message_content) > 20:
        increase += 0.3
    if len(message_content) > 50:
        increase += 0.2
    
    positive_words = ["喜欢", "爱", "谢谢", "开心", "想你", "好听", "棒", "厉害"]
    for word in positive_words:
        if word in message_content:
            increase += 0.5
            break
    
    user.intimacy = min(100.0, user.intimacy + increase)
    db.commit()
